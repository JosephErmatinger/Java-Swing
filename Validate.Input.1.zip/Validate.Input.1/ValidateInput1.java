/*
 * File Name:		ValidateInput1.java
 * Programmers:		Joe Ermatinger & Isaac Oxendale
 * Date Created:	2019/02/12
 */

import javax.swing.JOptionPane;

public class ValidateInput1
{
	public static void main(String[] args)
	{
		//variable declarations
		String userChoice;
		int    userInt = 0;
		//program heading output	
		JOptionPane.showMessageDialog( null, "Welcome to ValidateInput1.java \nby Joe Ermatinger and Isaac Oxendale");
		//begin while loop; validate only numbers from 50 to 101				
		while (userInt < 50 || userInt > 101)
		{			
			//prompt for user input
			userChoice = JOptionPane.showInputDialog( "Please enter a valid number: (50-101)");
			//receive input from GUI, and turn string into int
			userInt = Integer.parseInt(userChoice);
		}
		//congratulate the user on entering a proper value
		JOptionPane.showMessageDialog( null, "Congratulations! You entered a valid number!");
		//terminate
		System.exit(0);
	}
}


		